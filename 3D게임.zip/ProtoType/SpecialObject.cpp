#include "SpecialObject.h"
#include<iostream>
#include<GL/glut.h>
#include<GL/glu.h>
#include<GL/gl.h>